const DOMINIO_URL = 'http://negociosfechados.com';
const APP_URL = DOMINIO_URL + '/app';
// const DOCUMENTO_URI = document.documentURI;