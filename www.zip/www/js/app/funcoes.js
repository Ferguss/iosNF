function getsize(percent) {
	if (window.innerHeight > window.innerWidth) {
		return screen.width * percent;
	} else {
		return screen.height * percent;
	}
}

function getpixel(percent) {
	return getsize(percent) + 'px';
}

function getquadrado(percent) {
	return 'width:' + getpixel(percent) + ';height:' + getpixel(percent);
}

function moeda(elem) {

	var value = elem.value;

	// if (value < 10 && value != '') {
	// 	elem.value = '0,0' + value;
	// 	return;
	// }

	// if (value == '0,0') {
	// 	elem.value = '';
	// 	return;
	// }

	value = value.replace(/\D/g,'');
	value = value.replace(/(\d{1})(\d{0,2})$/,'$1,$2');
	elem.value = value;

}

function httpConnectAuth(url, base64user, callback) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			myApp.hidePreloader(); // Esconde o preloader
			callback(JSON.parse(xhttp.responseText)); // Transforma em JSON, e chama a função callback
		}
	};

	// Mostra o preloader
	myApp.showPreloader('Carregando...');

	xhttp.open("GET", url, true);
	xhttp.setRequestHeader("Authorization", "Basic " + base64user);
	xhttp.setRequestHeader("App", "App_anuncios");
	xhttp.send();
}

function httpConnect(url, callback) {

	if (!myApp) {
		var myApp = null;
	}

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			myApp ? myApp.hidePreloader() : ''; // Esconde o preloader
			callback(JSON.parse(xhttp.responseText)); // Transforma em JSON, e chama a função callback
		}
	};

	// Mostra o preloader
	myApp ? myApp.showPreloader('Carregando...') : '';

	xhttp.open("GET", url, true);
	xhttp.setRequestHeader("App", "App_anuncios");
	xhttp.send();
}

function httpPostAuth(url, form_data, callback) {

	usuario.login.getUser(function (result) {

		var user = result.rows.item(0).Usuario;
		var pass = result.rows.item(0).Senha;
		var base64user = getBase64(user,pass);

		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (xhttp.readyState == 4 && xhttp.status == 200) {
				myApp.hidePreloader(); // Esconde o preloader
				callback(JSON.parse(xhttp.responseText)); // Transforma em JSON, e chama a função callback
			}
		};

		// Mostra o preloader
		myApp.showPreloader('Carregando...');

		xhttp.open("POST", url, true);
		xhttp.setRequestHeader("Authorization", "Basic " + base64user);
		xhttp.setRequestHeader("App", "App_anuncios");
		xhttp.send(form_data);

	})
}

function b64toBlob(b64Data, contentType, sliceSize) {
	contentType = contentType || '';
	sliceSize = sliceSize || 512;

	var byteCharacters = atob(b64Data);
	var byteArrays = [];

	for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
		var slice = byteCharacters.slice(offset, offset + sliceSize);

		var byteNumbers = new Array(slice.length);
		for (var i = 0; i < slice.length; i++) {
			byteNumbers[i] = slice.charCodeAt(i);
		}

		var byteArray = new Uint8Array(byteNumbers);

		byteArrays.push(byteArray);
	}

	return new Blob(byteArrays, {type: contentType});
}