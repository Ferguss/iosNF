// window.onload = inicializa();
var arrayImagens;

function inicializa() {

	String.prototype.contains = function(it) {
		return this.indexOf(it) != -1;
	};

	Image.prototype.get_img_url = function(id) {
		this.src = APP_URL + '/getImg.php?imgId=' + id;
	};

	Image.prototype.get_thumb_url = function(id) {
		this.setAttribute('data-src', APP_URL + '/getthumb.php?imgId=' + id);
		this.className = 'lazy lazy-fadein';
	};

	getposts();
	banco.iniciar();

}

function buscapost(search) {
	httpConnect(APP_URL + '/getposts.php?query=' + search, makeposts);
}

function getposts() {
	httpConnect(APP_URL + '/getposts.php', makeposts);
}

function makeposts(json) {
	document.getElementsByClassName('posts')[0].innerHTML = ''; // Limpa a tela
	json.forEach(addpost); // Chama a função addpost para cada JSONObject
	myApp.initImagesLazyLoad('.homepage'); // Chama a função de carregar as imagens
}

function getPreviewPost(json) {

	$('#post_city').text(json.location);
	$('#post_descricao').text(json.descricao);
	$('#post_categoria').text(json.category);
	$('#post_tipo').text(json.ad_type);
	$('#telefone').get(0).href = 'tel: ' + json.user_mobile;

	var pai = document.querySelector('.swiper-container');
	var slider = pai.querySelector('.swiper-wrapper');
	var pager = pai.querySelector('.swiper-pagination');

	json.galeria.forEach(function (img_id) {
		
		var div = add_image_preview(img_id);

		slider.style.height = getpixel(0.7);
		slider.appendChild(div);

	});

	myApp.swiper('.swiper-container', {
		pagination:'.swiper-pagination'
	});
}

function add_image_preview (img_id) {
	var img = new Image();
	var div = document.createElement('div');

	div.style.width = getpixel(1);
	div.className = 'swiper-slide';

	img.get_img_url(img_id);
	img.onerror = function (argument) {
		this.src = 'images/bg_app_nf.png';
	};

	div.appendChild(img);
	return div;
}

function addpost(post) {

	var img = new Image();
	var div_post = document.createElement('div');
	div_post.innerHTML = document.getElementById('template_post').innerHTML;
	
	var title = div_post.getElementsByClassName('anuncio_titulo')[0];
	var date = div_post.getElementsByClassName('anuncio_data')[0];
	var price = div_post.getElementsByClassName('anuncio_preco')[0];
	var link = div_post.getElementsByTagName('a')[0];

	div_post.getElementsByClassName('post_thumb')[0].appendChild(img);

	link.id = post.Post_ID;
	date.innerHTML = post.Post_Date;
	title.innerHTML = post.Title;
	price.innerHTML = post.Price == '' ? 'Preço a combinar' : post.Price;

	img.className = 'anuncio_imagem';
	img.get_thumb_url(post.Post_ID);
	img.onerror = function() {
		this.src = 'images/bg_app_nf.png';
	};

	link.addEventListener("click", function(){

		mainView.router.loadPage('ver_anuncios.html'
			+ '?id=' + post.Post_ID
			+ '&title=' + post.Title
			+ '&date=' + post.Post_Date
			+ '&price=' + post.Price
		);

	});

	document.getElementsByClassName('posts')[0].appendChild(div_post.children[0]);
}

function anuncio_preview(attr) {

	$('#post_title').text(attr.title);	// Título
	$('#post_price').text(attr.price);	// Preço
	$('#post_date').text(attr.date);	// Data

	httpConnect(APP_URL + '/getpreview.php?id=' + attr.id, getPreviewPost);

}

/**
 * Oculta o atual, e exibe o input de busca
 */
function toogleSearch(element) {

	var input = element.parentElement.getElementsByTagName('input')[0];
	var form = element.parentElement.getElementsByTagName('form')[0];
	var img = element.getElementsByTagName('img')[0];

	input.value = '';

	if (form.className == 'search_close') {

		img.src = 'css/img/ic_clear_white.png';
		form.className = 'search_open';
		input.focus();

	} else {

		img.src = 'images/icons/white/busca_menu.png';
		form.className = 'search_close';

		getposts();

	}

}

function click_busca(element) {
	buscapost(element.children[0].value);
}

function panel_logged() {
	// body...
}

/**
 * Abre a página somente se estiver logado
 * Caso não esteja, chama a tela de login
 */
function page_logged(url) {

	if (usuario.login.isLogged) {
		mainView.router.loadPage(url);
	} else {

		var a = document.getElementById('LoginForm');
		a.querySelector('.url_callback').value = url;

		myApp.popup('.popup-login');

	}

}

function getNovoAd() {

	httpConnect(APP_URL + '/dadosNewAd.php', function (json) {

		// dadosNewAd = json;
		popularSpinnerId(document.getElementById('newAdType'), json.categ, 'Selecione um tipo');

		document.getElementById('newAdType').onchange = function () {

			var categ = getArrayFromSpinner(this, json.categ);

			popularSpinnerId (
				document.getElementById('newAdCateg'),
				categ.categ,
				'Selecione uma categoria'
			);

			$('#detalhes_anuncio').off();

			if (categ.extra) {
				alert_detalhes_ad(categ.extra);
			} else {
				var detalhes = $('#detalhes_anuncio');
				detalhes.get(0).className = 'template_app';
			}

			if (categ.feature) {
				popularListaDestaque(categ.feature);
			} else {
				document.querySelector('#lista_destaque').className = 'template_app';
			}

		}

	});

	httpConnect('cidades_do_brasil.json', function (json) {

		popularSpinnerSlug(document.getElementById('newAdState'), json, 'Selecione um estado');

		document.getElementById('newAdState').onchange = function () {
			
			popularSpinnerSlug (
				document.getElementById('newAdCity'),
				getArrayFromSpinner(this, json).city,
				'Selecione uma cidade'
			);

		}

	});

}

/**
 * Recebe os pacotes de anúncio para seleção do usuário
 * Popula o popup
 */
function getPacotes () {

	myApp.showIndicator();

	var formUl = document.querySelector('#FormPacotes ul');
	formUl.innerHTML = '';

	httpConnect(APP_URL + '/getPackages.php', function (json) {
		
		json.forEach(function (pacote) {

			console.log(pacote)
			
			var li = document.createElement('li');

			li.innerHTML = document.getElementById('template_pacotes').innerHTML;
			li.querySelector('input').value = pacote.package_id;
			li.querySelector('.item-title').innerHTML = pacote.package_title;

			formUl.appendChild(li);

		})

		myApp.hideIndicator();

	})

}

function fazerlogin(form) {
	var url = form.getElementsByClassName('url_callback')[0].value;
	var user = form.getElementsByClassName('form_input')[0].value;
	var pass = form.getElementsByClassName('form_input')[1].value;

	httpConnectAuth(APP_URL + "/islogged.php", getBase64(user, pass), function (json) {

		if (json.loggedin == true) {

			usuario.login.entrar(json.id, user, pass);
			myApp.closeModal($('.login-screen').get(0)); // Fecha o popup
			mainView.router.loadPage(url); // Abre a tela

		}

	});
}

function popularSpinnerId(element, array, titulo) {

	if (array != null) {

		if (titulo) {
			element.innerHTML = '';
			popularSpinnerId(element, [{id: 0, name: titulo}])
		}

		for(i = 0; i < array.length; i++) {

			var opt = document.createElement("option");

			opt.value = array[i].id;
			opt.innerHTML = array[i].name;

			element.appendChild(opt);

		}

	} else {
		element.innerHTML = '';
	}

}

function popularSpinnerSlug(element, array, titulo) {

	if (array != null) {

		if (titulo) {
			element.innerHTML = '';
			popularSpinnerSlug(element, [{id: 0, name: titulo}])
		}

		for(i = 0; i < array.length; i++) {

			var opt = document.createElement("option");

			opt.value = array[i].slug;
			opt.innerHTML = array[i].name;

			element.appendChild(opt);

		}

	} else {
		element.innerHTML = '';
	}

}

function popularListaDestaque(array) {

	var lista_destaque = document.getElementById('lista_destaque');
	lista_destaque.querySelector('.form_row_right').innerHTML = '';

	for (var i = 0; i < array.length; i++) {

		var label = document.createElement('label');
		label.className = 'label-checkbox item-content';

		label.innerHTML = '<input type="checkbox" name="dir_cusotm_field[cs_feature_list][]" value="'+ array[i].feature_slug +'">' +
							'<div class="item-media">' +
								'<i class="icon icon-form-checkbox"></i>' +
							'</div>' +
							'<div class="item-inner">' +
								'<div class="item-title">'+ array[i].feature_title +'</div>' +
							'</div>';

		lista_destaque.querySelector('.form_row_right').appendChild(label);

	}

	lista_destaque.className = 'form_row';

}

function getArrayFromSpinner(element, array) {
	if (element.selectedIndex > 0) {
		return array[element.selectedIndex - 1];
	}

	return [];
}

function publicar_anuncio (form) {

	var form_data = new FormData(form);

	usuario.login.getUser(function (result) {

		var estado = form.querySelector('#newAdState').value;
		var cidade = form.querySelector('#newAdCity').value;
		var local = ', ' + cidade + ', ' + estado + ', brasil';

		form.querySelector('#user_id').value = result.rows.item(0).UserId;
		form.querySelector('#ad_location').value = local;
		form.querySelector('#url_tema').value = DOMINIO_URL + '/wp-content/themes/negociofechado';
		form.querySelector('#quantidade_img').value = arrayImagens.length;

		if (arrayImagens.length > 0) {
			for(var i = 0; i < arrayImagens.length; i++){
				form_data.append('cs_featured_multiple_img[]', arrayImagens[i], (Date.now() + '.jpg'));
			}
		}

		// httpPostAuth('http://negociosfechados.com/app/json/post.php', form_data, function (json) {
		httpPostAuth(DOMINIO_URL + '/painel?action=add-directory', form_data, function (json) {
			if (json.cs_package == '0000000000') {

				myApp.alert(
					'Seu anúncio agora está aguardando moderação!',
					'Sucesso',
					function () {
						mainView.router.back()
						myApp.closeModal('.popup-pacotes')
					}
				)

			} else {

				var url = 'payment.html'
							+ '?price=' + json.cs_price.replace(',', '.')
							+ "&id=" + json.cs_post_id
							+ "&pack=" + json.cs_package
							+ "&featured=" + json.cs_featured
							+ "&name=" + form.elements['directory_title'].value
							+ "&uid=" + result.rows.item(0).UserId;

				cordova.InAppBrowser.open(url, '_blank', 'location=yes');
				
			}
		})
		
	})

}

function alert_detalhes_ad(json) {

	var detalhes = $('#detalhes_anuncio');
	var itens = $('#detalhes_anuncio .form_row_right');
	var div = document.createElement('div');

	itens.html('');

	for (var i = 0; i < json.length; i++) {
		
		var item;

		if (json[i].type == 'dropdown') {

			item = document.createElement('select');
			item.className = 'form_select';
			popularSpinnerSlug(item, json[i].options, json[i].name);

		} else if (json[i].type == 'text') {

			item = document.createElement('input');
			item.className = 'form_input';
			item.placeholder = json[i].name;

		}

		item.name = 'dir_cusotm_field[' + json[i].slug + ']';
		div.appendChild(item);
		
	}

	itens.html(div.innerHTML);
	detalhes.get(0).className = 'accordion-item';

}

function submit_anuncio (form) {
	if ($('form.novo_anuncio').valid()) {
		myApp.popup('.popup-pacotes');
	}
}

function submit_pacotes(form) {

	var anuncio = $(".novo_anuncio").get(0);
	var pacote = anuncio.elements['dir_cusotm_field[cs_directory_pkg_names]'];

	pacote.value = form.elements['radio_pacote'].value;
	publicar_anuncio(anuncio);

}