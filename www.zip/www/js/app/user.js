var usuario = {
	dados: {

	},
	favoritos: {

		adicionarFavorito: function(id) {
			// body...
		},
		removerFavorito: function(id) {
			// body...
		},
		getAll: function() {
			// body...
		},
		removeAll: function() {
			// body...
		}

	},
	login: {
		isLogged: false,
		getUser: function (callback) {
			banco.query('SELECT * FROM `User`', callback);
		},
		entrar: function (user_id, user, pass) {
			banco.query('INSERT INTO `User` (UserId, Usuario, Senha) VALUES ('+ user_id +', "'+ user +'", "'+ pass +'")');
			this.isLogged = true;
		},
		sair: function () {
			banco.query('DELETE FROM `User`');
			this.isLogged = false;
		}
	}
}

var banco = {
	iniciar: function () {
		var db = this.conectar();
		db.transaction (function (tx) {
			tx.executeSql ("CREATE TABLE IF NOT EXISTS `User` (`ID` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, `UserId`, `Nome`, `Usuario`,`Email`, `Senha`)");
			tx.executeSql ('SELECT * FROM `User`', [], function (tx, results) {
				
				if (results.rows.length > 0) {
					usuario.login.isLogged = true;
				}

			});
		});
	},
	conectar: function () {
		var db = openDatabase ('NegocioFechado', '1.0', 'Banco de dados do app', 2 * 1024 * 1024);
		return db;
	},
	query: function (string_query, callback) {

		var db = this.conectar();

		db.transaction (function (tx) {
			tx.executeSql (string_query, [], function (tx, results) {

				if (typeof(callback) == 'function') {
					callback(results);
				}

			}, null);
		});

	},
	delete_table: function (name_table) {
		this.query("DROP TABLE " + name_table);
	},
	resposta: null
}

function getBase64(user, pass) {
	return btoa(user + ":" + pass);
}
